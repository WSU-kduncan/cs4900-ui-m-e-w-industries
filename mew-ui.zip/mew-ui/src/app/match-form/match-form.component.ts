import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatchService, Match } from '../services/match.service';

@Component({
  selector: 'app-match-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './match-form.component.html',
  styleUrl: './match-form.component.css'
})
export class MatchFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private matchService = inject(MatchService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  matchForm!: FormGroup;
  isEditMode = signal(false);
  editingMatchId = signal<number | null>(null);
  isSubmitting = signal(false);

  ngOnInit(): void {
    // Initialize the form
    this.matchForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      gamertag: ['', [Validators.required, Validators.minLength(3)]],
      aboutUser: ['']
    });

    // Check if we're in edit mode by looking for an ID in the route
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode.set(true);
      this.editingMatchId.set(Number(id));
      this.loadMatchData(Number(id));
    }
  }

  // Load match data for editing
  private loadMatchData(id: number): void {
    const match = this.matchService.getMatchById(id);
    if (match) {
      this.matchForm.patchValue({
        name: match.name,
        gamertag: match.gamertag,
        aboutUser: match.aboutUser
      });
    }
  }

  // Handle form submission
  onSubmit(): void {
    if (this.matchForm.invalid) {
      // Mark all fields as touched to show validation errors
      Object.keys(this.matchForm.controls).forEach(key => {
        this.matchForm.get(key)?.markAsTouched();
      });
      return;
    }

    this.isSubmitting.set(true);

    const formValue = this.matchForm.value;

    if (this.isEditMode() && this.editingMatchId() !== null) {
      // UPDATE mode
      const updatedMatch: Match = {
        id: this.editingMatchId()!,
        name: formValue.name,
        gamertag: formValue.gamertag,
        aboutUser: formValue.aboutUser
      };

      this.matchService.updateMatch(updatedMatch).subscribe({
        next: () => {
          this.isSubmitting.set(false);
          alert('Match updated successfully!');
          this.router.navigate(['/']);
        },
        error: (error) => {
          console.error('Error updating match:', error);
          this.isSubmitting.set(false);
          alert('Error updating match. Please try again.');
        }
      });
    } else {
      // CREATE mode
      this.matchService.createMatch(formValue).subscribe({
        next: () => {
          this.isSubmitting.set(false);
          alert('Match created successfully!');
          this.matchForm.reset();
          // Refresh the matches list
          this.matchService.getAllMatches().subscribe();
        },
        error: (error) => {
          console.error('Error creating match:', error);
          this.isSubmitting.set(false);
          alert('Error creating match. Please try again.');
        }
      });
    }
  }

  // Cancel and go back
  onCancel(): void {
    this.router.navigate(['/']);
  }

  // Helper method to check if a field has an error
  hasError(fieldName: string, errorType: string): boolean {
    const field = this.matchForm.get(fieldName);
    return !!(field?.hasError(errorType) && field?.touched);
  }

  // Helper method to get error message
  getErrorMessage(fieldName: string): string {
    const field = this.matchForm.get(fieldName);
    if (field?.hasError('required')) {
      return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
    }
    if (field?.hasError('minlength')) {
      const minLength = field.errors?.['minlength'].requiredLength;
      return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must be at least ${minLength} characters`;
    }
    return '';
  }
}
