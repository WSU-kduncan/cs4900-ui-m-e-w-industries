import { Injectable, signal, inject} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';



// TypeScript interface defining the shape of API data
export interface User {
  id: number;
  name: string;
  username: string;
  email: string;
  phone?: string;
  website?: string;
}

export interface Match {
  id: number;
  name: string;
  gamertag: string;
  aboutUser: string;
}

@Injectable({
  providedIn: 'root'
})
export class MatchService {
  // Inject HttpClient
  private http = inject(HttpClient);

  private apiUrl = 'https://jsonplaceholder.typicode.com/users';

  // Writable signal to hold the array of matches
  private matchesSignal = signal<Match[]>([]);

  // Expose the signal as readonly
  readonly matches = this.matchesSignal.asReadonly();

  // Method that uses HttpClient to fetch data from API
  // Returns an Observable of User array
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.apiUrl);
  }

  // Fetch all matches from the server
  getAllMatches(): Observable<User[]> {
    return this.http.get<User[]>(this.apiUrl).pipe(
      tap((users) => {
        // Convert API users to Match format and update signal
        const matches: Match[] = users.map(user => ({
          id: user.id,
          name: user.name,
          gamertag: user.username,
          aboutUser: user.email
        }));
        this.matchesSignal.set(matches);
        console.log(this.matchesSignal.asReadonly)
      })
    );
  }

  //Post a new match to the server
  createMatch(match: Omit<Match, 'id'>): Observable<any> {
    return this.http.post<any>(this.apiUrl, match).pipe(
      tap((response) => {
        // Add the new match to the local signal
        const newMatch: Match = {
          id: response.id || this.generateId(),
          ...match
        };
        this.matchesSignal.update(matches => [...matches, newMatch]);
      })
    );
  }

  //Update an existing match on the server
  updateMatch(match: Match): Observable<Match> {
    return this.http.put<Match>(`${this.apiUrl}/${match.id}`, match).pipe(
      tap((updatedMatch) => {
        // Update the match in the local signal
        console.log(this.matchesSignal.asReadonly)
        this.matchesSignal.update(matches =>
          matches.map(m => m.id === updatedMatch.id ? updatedMatch : m)
        );
      })
    );
  }

  // Delete a match from the server
  deleteMatch(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`).pipe(
      tap(() => {
        // Remove the match from the local signal
        console.log(this.matchesSignal.asReadonly)
        this.matchesSignal.update(matches => matches.filter(m => m.id !== id));
        console.log(this.matchesSignal.asReadonly)
      })
    );
  }

  // Method to add a new match
  addMatch(name: string, gamertag: string, aboutUser: string = ''): void {
    if (!name.trim() || !gamertag.trim()) {
      return; // Don't add empty matches
    }

    const newMatch: Match = {
      id: this.generateId(),
      name: name.trim(),
      gamertag: gamertag.trim(),
      aboutUser: aboutUser.trim()
    };

    this.matchesSignal.update(matches => [...matches, newMatch]);
  }

  // Helper method to generate unique IDs
  private generateId(): number {
    const currentMatches = this.matchesSignal();
    return currentMatches.length > 0 
      ? Math.max(...currentMatches.map(m => m.id)) + 1 
      : 1;
  }

  // Method to get a single match by ID
  getMatchById(id: number): Match | undefined {
    return this.matchesSignal().find(m => m.id === id);
  }
}
