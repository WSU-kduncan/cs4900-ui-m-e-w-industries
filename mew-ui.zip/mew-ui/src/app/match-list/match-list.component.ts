import { Component, signal, inject, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { MatchService, User } from '../services/match.service';
import { MatchDetailComponent } from '../match-detail/match-detail.component';



@Component({
  selector: 'app-match-list',
  standalone: true,
  imports: [CommonModule, MatchDetailComponent,  RouterLink],
  templateUrl: './match-list.component.html',
  styleUrl: './match-list.component.css'
})
export class MatchListComponent {
  // Inject the MatchService
  private matchService = inject(MatchService);

  // Expose the matches signal from the service
  matches = this.matchService.matches;

  users = toSignal(this.matchService.getUsers(), { initialValue: [] as User[] });

  // Signal to track loading state
  isLoading = signal(false);

  ngOnInit(): void {
    // Fetch matches on component initialization
    this.refreshMatches();
  }

  // Refresh the matches list from the server
  refreshMatches(): void {
    this.isLoading.set(true);
    this.matchService.getAllMatches().subscribe({
      next: () => {
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Error fetching matches:', error);
        this.isLoading.set(false);
      }
    });
  }

  // Delete a match
  onDeleteMatch(id: number, name: string): void {
    if (confirm(`Are you sure you want to delete ${name}?`)) {
      this.matchService.deleteMatch(id).subscribe({
        next: () => {
          alert('Match deleted successfully!');
          // Refresh the list after successful deletion
          this.refreshMatches();
        },
        error: (error) => {
          console.error('Error deleting match:', error);
          alert('Error deleting match. Please try again.');
        }
      });
    }
  }

}
